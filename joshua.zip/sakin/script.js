window.addEventListener("load", () => {
    const loading = document.getElementById("loading");
    const content = document.getElementById("content");

    loading.style.transition = "opacity 10s ease";
    loading.style.opacity = "0";

    setTimeout(() => {
        loading.style.display = "none";
        content.style.display = "block";
    }, 500);
});
